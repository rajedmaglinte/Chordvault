import { extractDirective, updateDirective, toChordPro, ensureKeyDirective, detectFormat, getSongKey, songHasKey } from '../chords';

// ─── extractDirective ───────────────────────────────────────────────

describe('extractDirective', () => {
  it('extracts a standard directive value', () => {
    const content = '{title: Amazing Grace}\n{artist: John Newton}\n[G]Amazing';
    expect(extractDirective(content, 'title')).toBe('Amazing Grace');
    expect(extractDirective(content, 'artist')).toBe('John Newton');
  });

  it('returns null when directive is missing', () => {
    expect(extractDirective('{title: Test}\nlyrics', 'artist')).toBeNull();
  });

  it('handles x_ custom directives', () => {
    const content = '{x_tags: worship,praise}\n{x_language: en}\n{x_youtube: https://yt.com/abc}';
    expect(extractDirective(content, 'x_tags')).toBe('worship,praise');
    expect(extractDirective(content, 'x_language')).toBe('en');
    expect(extractDirective(content, 'x_youtube')).toBe('https://yt.com/abc');
  });

  it('trims whitespace around value', () => {
    expect(extractDirective('{title:   Spaced Out  }', 'title')).toBe('Spaced Out');
  });

  it('first match wins with duplicate directives', () => {
    const content = '{title: First}\n{title: Second}';
    expect(extractDirective(content, 'title')).toBe('First');
  });

  it('returns null for empty content', () => {
    expect(extractDirective('', 'title')).toBeNull();
  });
});

// ─── updateDirective ────────────────────────────────────────────────

describe('updateDirective', () => {
  it('replaces existing directive in-place', () => {
    const content = '{title: Old Title}\n{artist: Someone}\n[G]Lyrics';
    const result = updateDirective(content, 'title', 'New Title');
    expect(result).toBe('{title: New Title}\n{artist: Someone}\n[G]Lyrics');
  });

  it('inserts new directive in correct order', () => {
    const content = '{title: Song}\n[G]Lyrics';
    const result = updateDirective(content, 'artist', 'Artist Name');
    expect(result).toContain('{artist: Artist Name}');
    // artist should come after title
    const lines = result.split('\n');
    const titleIdx = lines.findIndex(l => l.includes('{title:'));
    const artistIdx = lines.findIndex(l => l.includes('{artist:'));
    expect(artistIdx).toBeGreaterThan(titleIdx);
  });

  it('inserts tempo after artist', () => {
    const content = '{title: Song}\n{artist: Bob}\n[G]Lyrics';
    const result = updateDirective(content, 'tempo', '120');
    const lines = result.split('\n');
    const artistIdx = lines.findIndex(l => l.includes('{artist:'));
    const tempoIdx = lines.findIndex(l => l.includes('{tempo:'));
    expect(tempoIdx).toBeGreaterThan(artistIdx);
  });

  it('removes directive when value is null', () => {
    const content = '{title: Song}\n{artist: Bob}\n[G]Lyrics';
    const result = updateDirective(content, 'artist', null);
    expect(result).not.toContain('{artist:');
    expect(result).toContain('{title: Song}');
    expect(result).toContain('[G]Lyrics');
  });

  it('removes directive when value is empty string', () => {
    const content = '{title: Song}\n{artist: Bob}\n[G]Lyrics';
    const result = updateDirective(content, 'artist', '');
    expect(result).not.toContain('{artist:');
  });

  it('inserts into empty content', () => {
    const result = updateDirective('', 'title', 'New Song');
    expect(result).toBe('{title: New Song}\n');
  });

  it('does not corrupt surrounding lyrics', () => {
    const content = '{title: Song}\n\n[G]First line\n[C]Second line';
    const result = updateDirective(content, 'artist', 'New Artist');
    expect(result).toContain('[G]First line');
    expect(result).toContain('[C]Second line');
  });

  it('handles x_ directives', () => {
    const content = '{title: Song}\n[G]Lyrics';
    const result = updateDirective(content, 'x_tags', 'worship,praise');
    expect(result).toContain('{x_tags: worship,praise}');
  });

  it('removes trailing whitespace on directive line', () => {
    const content = '{title: Song}   \n[G]Lyrics';
    const result = updateDirective(content, 'title', 'Updated');
    expect(result).toBe('{title: Updated}\n[G]Lyrics');
  });

  it('replaces an indented directive instead of adding a second one', () => {
    expect(updateDirective('  {title: A}\nx', 'title', 'B')).toBe('{title: B}\nx');
  });
});

// ─── detectFormat ───────────────────────────────────────────────────

describe('detectFormat', () => {
  it('detects ChordPro format', () => {
    expect(detectFormat('[G]Let it [D]be')).toBe('ChordPro');
  });

  it('detects chords-over-lyrics format (UG parser picks it up)', () => {
    const content = '  G        D\n  Let it be';
    // UG parser matches chords-over-lyrics first — both are valid detections
    expect(detectFormat(content)).toBe('Ultimate Guitar');
  });

  it('returns null for empty content', () => {
    expect(detectFormat('')).toBeNull();
    expect(detectFormat('   ')).toBeNull();
  });

  it('returns null for lyrics with no chords', () => {
    expect(detectFormat('Just some lyrics\nwithout any chords')).toBeNull();
  });

  it('section labels alone parsed by UG parser (no real chords for ChordPro)', () => {
    // UG parser treats [Chorus]/[Verse] as valid UG section markers
    // The ChordPro path correctly filters them out, but UG parser picks them up
    const result = detectFormat('[Chorus]\nJust lyrics here\n[Verse]\nMore lyrics');
    // If UG parser detects chords in the section-labeled content, it returns 'Ultimate Guitar'
    // If no chords detected at all, returns null
    expect(result === 'Ultimate Guitar' || result === null).toBe(true);
  });

  it('detects ChordPro even with section labels present', () => {
    // Has both section labels AND real chords
    expect(detectFormat('[Chorus]\n[G]Let it [D]be')).toBe('ChordPro');
  });
});

// ─── toChordPro + directive preservation ────────────────────────────

describe('toChordPro', () => {
  it('preserves x_ directives through conversion', () => {
    const content = '{title: Song}\n{x_tags: worship}\n{x_language: en}\n\n  G        D\n  Let it be';
    const result = toChordPro(content);
    expect(result).toContain('{x_tags: worship}');
    expect(result).toContain('{x_language: en}');
    expect(result).toContain('{title: Song}');
  });

  it('preserves standard directives through conversion', () => {
    const content = '{title: Amazing Grace}\n{artist: John Newton}\n{key: G}\n\n  G        D\n  Let it be';
    const result = toChordPro(content);
    expect(result).toContain('{title:');
    expect(result).toContain('{artist:');
    expect(result).toContain('{key:');
  });

  it('passes through already-ChordPro content cleanly', () => {
    const content = '{title: Song}\n[G]Amazing [C]grace';
    const result = toChordPro(content);
    // Should still have the title and chord content
    expect(result).toContain('{title:');
    // Should contain chord markers
    expect(result).toMatch(/\[G\]/);
  });

  it('converts chords-over-lyrics to ChordPro bracket format', () => {
    const content = '  G        D\n  Let it   be';
    const result = toChordPro(content);
    // Result should contain inline [chord] markers
    expect(result).toMatch(/\[[A-G][b#]?\]/);
  });

  it('returns original content on parse failure', () => {
    const garbage = '';
    const result = toChordPro(garbage);
    expect(result).toBe(garbage);
  });
});

// ─── ensureKeyDirective ─────────────────────────────────────────────

describe('ensureKeyDirective', () => {
  it('does not duplicate existing key directive', () => {
    const content = '{key: G}\n[G]Amazing [C]grace';
    const result = ensureKeyDirective(content);
    expect(result).toBe(content);
  });

  it('adds key from first chord when missing', () => {
    const content = '[G]Amazing [C]grace';
    const result = ensureKeyDirective(content);
    expect(result).toContain('{key: G}');
    // Original content should still be there
    expect(result).toContain('[G]Amazing');
  });

  it('handles minor key chords', () => {
    const content = '[Am]Lyrics here [Em]more';
    const result = ensureKeyDirective(content);
    expect(result).toContain('{key: Am}');
  });

  it('accepts a key directive in any case', () => {
    expect(ensureKeyDirective('{Key: G}\n[C]a')).toBe('{Key: G}\n[C]a');
  });

  it('treats an empty key directive as missing', () => {
    expect(ensureKeyDirective('{key: }\n[C]a')).toMatch(/^\{key: C\}\n/);
  });
});

// ─── renderChordPro (Section Parsing & Labeling) ───────────────────

import { renderChordPro } from '../chords';

describe('renderChordPro sections', () => {
  it('promotes paragraph type from first line label', () => {
    const content = 'Chorus\n[G]Amazing grace';
    const html = renderChordPro(content);
    // Should have paragraph chorus class
    expect(html).toContain('class="paragraph chorus"');
    // Should have a label badge for Chorus
    expect(html).toContain('class="label">Chorus</h3>');
  });

  it('handles numbered sections like Verse 1', () => {
    const content = 'Verse 1\n[G]Lyrics';
    const html = renderChordPro(content);
    expect(html).toContain('class="paragraph verse"');
    expect(html).toContain('class="label">Verse 1</h3>');
  });

  it('recognizes Pre-Chorus with or without hyphen', () => {
    const html1 = renderChordPro('Pre-Chorus\n[G]Lyrics');
    expect(html1).toContain('class="paragraph prechorus"');

    const html2 = renderChordPro('PreChorus\n[G]Lyrics');
    expect(html2).toContain('class="paragraph prechorus"');
  });

  it('does not promote if chords are present on the first line', () => {
    // If it has chords, it's probably not just a label
    const content = '[G]Chorus\n[C]Lyrics';
    const html = renderChordPro(content);
    expect(html).not.toContain('class="paragraph chorus"');
  });

  it('handles Bridge with special styling in HTML', () => {
    const content = 'Bridge\n[G]Lyrics';
    const html = renderChordPro(content);
    expect(html).toContain('class="paragraph bridge"');
  });

  it('handles bracketed labels like [Chorus]', () => {
    const content = '[Chorus]\n[G]Lyrics';
    const html = renderChordPro(content);
    expect(html).toContain('class="paragraph chorus"');
    expect(html).toContain('class="label">Chorus</h3>');
  });

  it('shows the label written on a section directive', () => {
    const html = renderChordPro('{start_of_verse: Verse 2}\n[G]Lyrics\n{end_of_verse}\n\n{start_of_chorus: Reff}\n[C]Lyrics\n{end_of_chorus}');
    expect(html).toContain('<div class="paragraph verse"><div class="row"><h3 class="label">Verse 2</h3>');
    expect(html).toContain('<div class="paragraph chorus"><div class="row"><h3 class="label">Reff</h3>');
  });

  it('prefers the directive label over its type', () => {
    expect(renderChordPro('{start_of_verse: Pre-Chorus}\n[G]Lyrics\n{end_of_verse}')).toContain('class="label">Pre-Chorus</h3>');
  });

  it('names an unlabelled section from its type in words', () => {
    expect(renderChordPro('{start_of_pre_chorus}\n[G]Lyrics\n{end_of_pre_chorus}')).toContain('class="label">Pre Chorus</h3>');
  });

  it('escapes a directive label', () => {
    expect(renderChordPro('{start_of_verse: <b>1</b>}\n[G]Lyrics\n{end_of_verse}')).toContain('class="label">&lt;b&gt;1&lt;/b&gt;</h3>');
  });

  it('recognizes "Pre Chorus :" with a space as a heading', () => {
    const html = renderChordPro('Pre Chorus :\n[G]Lyrics');
    expect(html).toContain('class="paragraph prechorus"');
    expect(html).toContain('class="label">Pre Chorus</h3>');
  });
});

describe('renderChordPro number notation', () => {
  it('keeps bracketed section labels intact in number notation', () => {
    const content = '{key: G}\n[Chorus]\n[G]Amazing [C]grace';
    const html = renderChordPro(content, 0, true);
    expect(html).toContain('class="label">Chorus</h3>');
    expect(html).toContain('class="paragraph chorus"');
    expect(html).not.toContain('4horus');
  });

  it('still converts real chords to numbers', () => {
    const content = '{key: G}\n[G]Amazing [C]grace';
    const html = renderChordPro(content, 0, true);
    expect(html).toContain('>1<');
    expect(html).toContain('>4<');
  });
});

describe('getSongKey', () => {
  it.each([
    ['Amaj7', 'A'],
    ['Am7', 'Am'],
    ['Cmaj7/G', 'C'],
    ['Cm7/G', 'Cm'],
    ['H', 'H'],
    ['Hm', 'Hm'],
  ])('infers the native letter root of %s', (chord, key) => {
    const content = `[Chorus]\n[${chord}]lyrics`;
    expect(getSongKey(content)).toBe(key);
    expect(ensureKeyDirective(content)).toBe(`{key: ${key}}\n${content}`);
  });

  it.each(['1', 'Do', 'Rem'])('does not infer a letter key from %s', chord => {
    const content = `[${chord}]lyrics`;
    expect(getSongKey(content)).toBe('');
    expect(ensureKeyDirective(content)).toBe(content);
  });

  it('skips solfege and infers the next eligible letter root', () => {
    const content = '[Do]words [G]lyrics';
    expect(getSongKey(content)).toBe('G');
    expect(ensureKeyDirective(content)).toBe(`{key: G}\n${content}`);
  });

  it('keeps an explicit key ahead of inferred chord roots', () => {
    const content = '{key: D}\n[Amaj7]lyrics';
    expect(getSongKey(content)).toBe('D');
    expect(ensureKeyDirective(content)).toBe(content);
  });

  it('reads the key directive when present', () => {
    expect(getSongKey('{key: A}\n[A]Amazing')).toBe('A');
  });

  it('derives the key from the first real chord when no directive exists', () => {
    expect(getSongKey('[A]Amazing [D]grace')).toBe('A');
  });

  it('ignores a leading bracketed section label when deriving the key', () => {
    expect(getSongKey('[Chorus]\n[A]Amazing [D]grace [E]how')).toBe('A');
  });

  it('keeps minor quality when deriving from a minor chord', () => {
    expect(getSongKey('[Am]Amazing [Dm]grace')).toBe('Am');
  });

  it('returns an empty string when there are no chords at all', () => {
    expect(getSongKey('just some lyrics')).toBe('');
  });
});

describe('ensureKeyDirective', () => {
  it('leaves content untouched when a key directive already exists', () => {
    const content = '{key: G}\n[G]Amazing';
    expect(ensureKeyDirective(content)).toBe(content);
  });

  it('prepends a key derived from the first real chord', () => {
    expect(ensureKeyDirective('[A]Amazing [D]grace')).toBe('{key: A}\n[A]Amazing [D]grace');
  });

  it('ignores a leading bracketed section label when deriving the key', () => {
    const content = '[Chorus]\n[A]Amazing [D]grace';
    expect(ensureKeyDirective(content)).toBe(`{key: A}\n${content}`);
  });
});


import { prepareSong } from '../chords';

describe('key metadata', () => {
  it('distinguishes explicit key metadata from inferred roots', () => {
    expect(songHasKey('{key: G}\n[G]a', 2)).toBe(true);
    expect(songHasKey('[G]a', 0)).toBe(false);
    expect(songHasKey('lyrics only', 0)).toBe(false);
    expect(songHasKey('{key: Chorus}\n[C]a', 2)).toBe(false);
    expect(getSongKey('{key: G}\n[G]a', 2)).toBe('A');
  });

  it('uses the first key value when keys are duplicated', () => {
    const content = '{key: G}\n{key: A}\n[C]lyrics';
    expect(songHasKey(content, 0)).toBe(true);
    expect(getSongKey(content)).toBe('G');
    expect(prepareSong(content, 0)?.key).toBe('G');
  });

  it.each([
    '{key: }\n[C]lyrics',
    '{key: }\n{key: G}\n[C]lyrics',
  ])('treats an empty first key as absent: %s', content => {
    expect(songHasKey(content, 0)).toBe(false);
    expect(getSongKey(content)).toBe('C');
    const prepared = prepareSong(content, 0, true);
    expect(prepared).not.toBeNull();
    expect(prepared!.key).toBe('');
    expect(prepared!.getChords()).toEqual(['C']);
  });
});

describe('prepareSong', () => {
  const chordsOf = (song: NonNullable<ReturnType<typeof prepareSong>>) => {
    const out: string[] = [];
    song.mapChordLyricsPairs((p) => {
      const c = (p as { chords?: string }).chords;
      if (c) out.push(c);
      return p;
    });
    return out;
  };

  it('transposes and keeps sharp preference', () => {
    const song = prepareSong('{key: G}\n[G]a [C]b', 2);
    expect(song).not.toBeNull();
    expect(chordsOf(song!)).toEqual(['A', 'D']);
  });

  it('converts to numbers when nashville is on', () => {
    const song = prepareSong('{key: G}\n[G]a [C]b', 0, true);
    expect(chordsOf(song!)).toEqual(['1', '4']);
  });

  // parseSongAuto falls back to a lyrics-only ChordPro parse when it finds no
  // chords, so content without chords still yields a song rather than null.
  it('still returns a song for chordless content', () => {
    expect(prepareSong('just some words')).not.toBeNull();
  });
});

describe('comment directives (ChordSheetJS 18 sends them as tags)', () => {
  it('shows {comment: Intro} as a section label', () => {
    const html = renderChordPro('{key: G}\n{comment: Intro}\n[G] [D] [Em] [C]\n\n{start_of_verse}\n[G]Amazing grace\n{end_of_verse}');
    expect(html).toContain('<h3 class="label">Intro</h3>');
  });

  it('shows the {c: ...} short form too', () => {
    expect(renderChordPro('{key: G}\n{c: Intro}\n[G] [D]')).toContain('<h3 class="label">Intro</h3>');
  });

  it('keeps other comments as comment text', () => {
    expect(renderChordPro('{key: G}\n{comment: Play softly}\n[G]Grace')).toContain('<div class="comment">Play softly</div>');
  });
});
