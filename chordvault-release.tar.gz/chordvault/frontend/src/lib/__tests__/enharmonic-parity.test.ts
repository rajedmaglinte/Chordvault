import { describe, it, expect } from 'vitest';
import { ENHARMONIC_MAP as frontendMap, ALL_KEYS as frontendAllKeys, ALL_KEYS_MINOR as frontendAllKeysMinor } from '../keys';
import backend from '../../../../lib/enharmonic.js';

// Both runtime adapters consume the shared data; the backend adds German keys.
describe('enharmonic map parity', () => {
  it('backend and frontend maps are identical', () => {
    expect(backend.ENHARMONIC_MAP).toEqual(frontendMap);
  });

  it('backend normalizeKey matches the map, including the Fb and Cb entries', () => {
    expect(backend.normalizeKey('Cb')).toBe('B');
    expect(backend.normalizeKey('Cbm')).toBe('Bm');
    expect(backend.normalizeKey('Fb')).toBe('E');
    expect(backend.normalizeKey('Fbm')).toBe('Em');
    expect(backend.normalizeKey('Gb')).toBe('F#');
    expect(backend.normalizeKey('G')).toBe('G');
  });

  // The backend's migration gate (lib/songKey.js) validates its output against
  // these lists to reject non-canonical spellings before they can reach an
  // irreversible column drop. A drifted copy would silently widen or narrow
  // that gate, so it's held to the same parity guarantee as the map above.
  it('backend and frontend canonical key lists are identical', () => {
    expect(backend.ALL_KEYS).toEqual(frontendAllKeys);
    expect(backend.ALL_KEYS_MINOR).toEqual(frontendAllKeysMinor);
  });

  // CANONICAL_KEYS is backend-only (it must NOT feed the frontend key-picker,
  // which only offers ALL_KEYS/ALL_KEYS_MINOR), but it's still derived from
  // those two lists plus the German 'H'/'Hm' forms, so pin the derivation
  // explicitly rather than letting it drift from a hand-maintained duplicate.
  it('backend CANONICAL_KEYS is the frontend key lists plus German H/Hm notation', () => {
    expect(backend.CANONICAL_KEYS).toEqual([...frontendAllKeys, ...frontendAllKeysMinor, 'H', 'Hm']);
  });
});
