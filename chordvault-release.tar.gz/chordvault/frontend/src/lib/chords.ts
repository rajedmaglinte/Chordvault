import * as ChordSheetJS from 'chordsheetjs';
import { escHtml } from './util';
import { normalizeKey, normalizeChord } from './keys';
import { CHORD_TOKEN, cleanChordName } from './chordTokens';
import { extractDirective } from '../../../shared/chordpro.mjs';
import type { SetlistEntry, SetlistPreferences } from '../types';

// preserveWhitespace is only an option on UltimateGuitarParser; the other two take
// no constructor arguments and accept their options on parse() instead.
const PARSERS = [
  { make: () => new ChordSheetJS.ChordProParser(), label: 'ChordPro' },
  { make: () => new ChordSheetJS.UltimateGuitarParser({ preserveWhitespace: false }), label: 'Ultimate Guitar' },
  { make: () => new ChordSheetJS.ChordsOverWordsParser(), label: 'Chords over lyrics' },
] as const;


const DIRECTIVE_RE = /^\{([a-z_]+):\s*([^}]*)\}$/i;
const DIRECTIVE_LINE_RE = /^\{[a-z_]+:.*\}$/i;
const DIRECTIVE_ORDER = ['title', 'artist', 'key', 'tempo', 'capo', 'x_youtube', 'x_tags', 'x_language'];

const SECTION_NAMES = 'Verse|Chorus|Bridge|Intro|Outro|Interlude|Pre[- ]?Chorus|Ending|Tag|Coda|Break|Solo|Instrumental|Refrain';
// Matches a section label with or without surrounding brackets and a trailing colon,
// e.g. "Chorus", "Verse 2", "[Bridge]", "Pre-Chorus:".
export const SECTION_LABEL_RE = new RegExp(`^\\[?(?:${SECTION_NAMES})\\s*\\d*:?\\]?$`, 'i');

export { extractDirective };

export function updateDirective(content: string, name: string, value: string | null): string {
  const re = new RegExp(`^[ \\t]*\\{${name}:.*\\}[ \\t]*$`, 'im');
  if (!value || !value.trim()) {
    // Remove directive line (and trailing newline if present)
    return content.replace(new RegExp(`^[ \\t]*\\{${name}:.*\\}[ \\t]*\\n?`, 'im'), '');
  }
  const newLine = `{${name}: ${value.trim()}}`;
  if (re.test(content)) {
    return content.replace(re, newLine);
  }
  // Insert at correct position among directives at top of file
  const lines = content.split('\n');
  const targetIdx = DIRECTIVE_ORDER.indexOf(name);
  let insertAt = 0;
  for (let i = 0; i < lines.length; i++) {
    const dm = lines[i].match(DIRECTIVE_RE);
    if (dm) {
      const existingIdx = DIRECTIVE_ORDER.indexOf(dm[1].toLowerCase());
      if (existingIdx < targetIdx || (existingIdx === -1 && targetIdx === -1)) {
        insertAt = i + 1;
      }
    } else if (DIRECTIVE_LINE_RE.test(lines[i])) {
      insertAt = i + 1;
    } else {
      break;
    }
  }
  lines.splice(insertAt, 0, newLine);
  return lines.join('\n');
}

export function parseSongAutoWithFormat(rawContent: string): { song: ChordSheetJS.Song; format: string | null } | null {
  // Pre-process content: force all chords to preferred enharmonic spellings (Sharps)
  // and fix spacing issues in slash chords (e.g. [A / C#] -> [A/C#]) BEFORE parsing.
  // This ensures transpose and Nashville work correctly.
  let content = rawContent.replace(new RegExp(CHORD_TOKEN.source, 'g'), (chord) => `[${cleanChordName(chord.slice(1, -1))}]`);

  // Also normalize Chords-over-lyrics format (lines with only chords)
  content = content.split('\n').map(line => {
    const isChordLine = /^\s*[A-G][b#]?\S*(?:\s+[A-G][b#]?\S*)+\s*$/m.test(line);
    if (isChordLine) {
      return line.split(/(\s+)/).map(chunk => {
        if (chunk.trim() === '') return chunk;
        return cleanChordName(chunk);
      }).join('');
    }
    return line;
  }).join('\n');

  // Detect true ChordPro bracket chords — exclude section labels like [Chorus], [Bridge]
  const bracketContents = (content.match(/\[([A-G][^\]]*)\]/g) || []).map(b => b.slice(1, -1));
  const hasBracketChords = bracketContents.some(c => !SECTION_LABEL_RE.test(c));

  // ChordPro directives like {start_of_verse} or {key: C}
  const hasDirectives = /\{[a-z_]+[:}]/.test(content);

  // Use ChordPro parser when content has real inline [chord] markers or {directives} without chords-over-lyrics
  const hasChordsOverLyrics = /^\s*[A-G][b#]?\S*(?:\s+[A-G][b#]?\S*)+\s*$/m.test(content);
  const isChordPro = hasBracketChords || (hasDirectives && !hasChordsOverLyrics);
  const order = isChordPro ? [0, 1, 2] : [1, 2, 0];

  for (const idx of order) {
    const p = PARSERS[idx];
    try {
      const song = p.make().parse(content);
      const hasChords = song.paragraphs.some((par) =>
        par.lines.some((l) =>
          l.items.some((it) => {
            const chords = (it as { chords?: string }).chords;
            if (!chords) return false;
            if (p.label === 'ChordPro' && SECTION_LABEL_RE.test(chords)) return false;
            return true;
          })
        )
      );
      if (hasChords) return { song, format: p.label };
    } catch { /* try next parser */ }
  }

  // Fallback: parse as ChordPro (lyrics only, no chords detected)
  try {
    return { song: new ChordSheetJS.ChordProParser().parse(content), format: null };
  } catch { /* fall through */ }
  return null;
}

export function parseSongAuto(content: string): ChordSheetJS.Song | null {
  const result = parseSongAutoWithFormat(content);
  return result ? result.song : null;
}

export function detectFormat(content: string): string | null {
  if (!content || !content.trim()) return null;
  const result = parseSongAutoWithFormat(content);
  return result ? result.format : null;
}

export function toChordPro(content: string): string {
  // Separate directive lines from body so x_ directives survive UG parser conversion
  const lines = content.split('\n');
  const directiveLines: string[] = [];
  let bodyStart = 0;
  for (let i = 0; i < lines.length; i++) {
    if (DIRECTIVE_LINE_RE.test(lines[i].trim())) {
      directiveLines.push(lines[i]);
      bodyStart = i + 1;
    } else if (lines[i].trim() === '') {
      bodyStart = i + 1;
    } else {
      break;
    }
  }
  const body = lines.slice(bodyStart).join('\n');
  const song = parseSongAuto(body || content);
  if (!song) return content;
  try {
    let result = new ChordSheetJS.ChordProFormatter({ normalizeChords: false } as Record<string, unknown>).format(song);
    // Remove any directives the formatter produced that we already have in directiveLines
    if (directiveLines.length > 0) {
      const existingNames = new Set(directiveLines.map(l => {
        const m = l.match(DIRECTIVE_RE);
        return m ? m[1].toLowerCase() : '';
      }).filter(Boolean));
      const resultLines = result.split('\n');
      const filtered = resultLines.filter(l => {
        const m = l.match(DIRECTIVE_RE);
        return !(m && existingNames.has(m[1].toLowerCase()));
      });
      result = [...directiveLines, ...filtered].join('\n');
    }
    return result;
  } catch { return content; }
}

// Returns the raw root of the first item that is a real chord (e.g. 'A', 'Am'), or null.
// Section labels are skipped: ChordProParser turns [Chorus] into a chord, and a naive
// root match would read the leading 'C' of "Chorus" as the key.
function firstChordRoot(song: ChordSheetJS.Song): string | null {
  for (const p of song.paragraphs) {
    for (const line of p.lines) {
      for (const item of line.items) {
        const chords = (item as { chords?: string }).chords?.trim();
        if (!chords || SECTION_LABEL_RE.test(chords)) continue;
        const chord = ChordSheetJS.Chord.parse(chords);
        if (chord?.root?.type === 'symbol') return chord.root.toString();
      }
    }
  }
  return null;
}

export function ensureKeyDirective(content: string): string {
  if (extractDirective(content, 'key')) return content;
  try {
    const root = firstChordRoot(new ChordSheetJS.ChordProParser().parse(content));
    if (root) return `{key: ${root}}\n${content}`;
  } catch { /* fall through */ }
  return content;
}

/** Text of a comment line, or null. ChordSheetJS 18 sends `{comment: x}` as a Tag on a plain line. */
function commentText(l: ChordSheetJS.Line): string | null {
  const firstItem = l.items[0];
  if (firstItem instanceof ChordSheetJS.Tag && firstItem.isComment()) return firstItem.value || '';
  if (l.type !== 'comment') return null;
  return (firstItem && 'content' in firstItem ? (firstItem as ChordSheetJS.Comment).content :
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (firstItem && 'lyrics' in firstItem ? (firstItem as any).lyrics : '')) || '';
}

const UNTYPED = ['none', 'indeterminate'];

/** The cleaned label of a line that holds only a section label (a comment, a lyric or a bracket chord), else null. */
function lineLabel(l: ChordSheetJS.Line | undefined, comment = l && commentText(l)): string | null {
  if (!l) return null;
  let text = comment?.trim();
  if (text === undefined) {
    const first = l.items[0];
    if (!first || !('lyrics' in first)) return null;
    const lyrics = (first.lyrics || '').trim();
    const chords = (first.chords || '').trim();
    // Only one of them should be present for a pure label line
    if (!lyrics === !chords) return null;
    text = lyrics || chords;
  }
  return SECTION_LABEL_RE.test(text) ? text.replace(/[[\]:]/g, '').trim() : null;
}

/** CSS class for a written label: "Pre Chorus" and "Pre-Chorus" become prechorus, "Verse 1" becomes verse. */
const labelType = (label: string) => label.toLowerCase().replace(/[^a-z]/g, '');

/** Heading for a section directive with no label: pre_chorus becomes "Pre Chorus". */
const typeHeading = (type: string) => type.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');

const labelRow = (label: string) => `<div class="row"><h3 class="label">${escHtml(label)}</h3></div>`;

class ResponsiveHtmlFormatter {
  format(song: ChordSheetJS.Song): string {
    return song.paragraphs.map(p => this.renderParagraph(p)).join('');
  }

  private renderParagraph(p: ChordSheetJS.Paragraph): string {
    const content = p.lines.map(l => this.renderLine(l)).join('');
    // Promote an untyped paragraph whose first line is a label (helps CSS match)
    const firstLabel = UNTYPED.includes(p.type) ? lineLabel(p.lines[0]) : null;
    const type = firstLabel ? labelType(firstLabel) : p.type;

    // The paragraph must have content, which prevents empty badges for metadata
    const hasRenderableContent = p.lines.some(l =>
      l.items.some(it => ('lyrics' in it && it.lyrics?.trim()) || ('chords' in it && it.chords?.trim()))
    );
    const heading = !UNTYPED.includes(type) && !content.includes('class="label"') && hasRenderableContent
      ? labelRow(p.label || typeHeading(type)) : '';

    return `<div class="paragraph ${type}">${heading}${content}</div>`;
  }

  private renderLine(l: ChordSheetJS.Line): string {
    const comment = commentText(l);
    const label = lineLabel(l, comment);
    if (label !== null) return labelRow(label);
    if (comment !== null) return `<div class="comment">${escHtml(comment)}</div>`;

    const content = l.items.map(it => this.renderItem(it as ChordSheetJS.ChordLyricsPair)).join('');
    return `<div class="row">${content}</div>`;
  }

  private renderItem(it: ChordSheetJS.ChordLyricsPair): string {
    const lyrics = it.lyrics || '';

    // No lyrics, or whitespace-only lyrics (chord-only rows like intros and
    // instrumental breaks). Render an empty lyric span so CSS (.lyrics:empty)
    // collapses the otherwise-blank line. The chord sets the column width, so
    // horizontal spacing between chords is preserved.
    if (!lyrics.trim()) {
      const chord = it.chords ? normalizeChord(it.chords) : '';
      return `<span class="column"><span class="chord">${escHtml(chord)}</span><span class="lyrics"></span></span>`;
    }

    // Split lyrics by whitespace chunks. We treat any sequence of spaces as one unit
    // so the browser doesn't wrap "inside" the spacing between chords.
    const chunks = lyrics.split(/(\s+)/).filter((chunk: string) => chunk !== '');
    let chordPlaced = false;

    return chunks.map((chunk: string) => {
      const isSpace = /\s+/.test(chunk);

      // If we've already placed the chord for this item, and this is a space,
      // output it as raw text. To prevent ugly wrapping between multiple spaces,
      // we ensure this raw text chunk is an unbreakable unit.
      if (isSpace && chordPlaced) {
        return escHtml(chunk);
      }

      // If we haven't placed the chord yet, or if it's a word, wrap in a column.
      // The chord is only attached to the VERY FIRST chunk (word or space).
      const rawChord = chordPlaced ? '' : (it.chords || '');
      const currentChord = normalizeChord(rawChord);
      chordPlaced = true;

      const chords = `<span class="chord">${escHtml(currentChord)}</span>`;
      const lyricText = escHtml(chunk);
      return `<span class="column">${chords}<span class="lyrics">${lyricText}</span></span>`;
    }).join('');
  }
}

export function prepareSong(content: string, semitones = 0, nashville = false): ChordSheetJS.Song | null {
  try {
    const song = parseSongAuto(content);
    if (!song) return null;

    // Fix accidentals after transposition to preserve sharp preference and prevent auto-correction
    const transposed = fixChordAccidentals(semitones !== 0 ? keepSectionLabels(song, song.transpose(semitones)) : song);

    const key = transposed.key;

    if (nashville && key && ChordSheetJS.Chord) {
      return convertToNashville(transposed, key);
    }
    return transposed;
  } catch {
    return null;
  }
}

export function renderChordPro(content: string, semitones = 0, nashville = false): string {
  try {
    const song = prepareSong(content, semitones, nashville);
    if (!song) throw new Error('parse failed');
    return `<div class="chord-sheet">${new ResponsiveHtmlFormatter().format(song)}</div>`;
  } catch {
    return `<pre style="font-family:var(--font-mono);font-size:13px;white-space:pre-wrap;color:var(--text)">${escHtml(content)}</pre>`;
  }
}

/**
 * ChordProParser reads a label line like [Chorus] as a chord, and transposing then rewrites it
 * ("Chorus" up a tone becomes "Dhorus", "Intro" becomes "IIntro"), so the section heading and its
 * jump button disappear. Put the original labels back after transposing.
 */
function keepSectionLabels(original: ChordSheetJS.Song, transposed: ChordSheetJS.Song): ChordSheetJS.Song {
  const before: string[] = [];
  original.mapChordLyricsPairs((pair) => { before.push(pair.chords); return pair; });
  let i = 0;
  return transposed.mapChordLyricsPairs((pair) => {
    const label = before[i++];
    return label !== undefined && SECTION_LABEL_RE.test(label) ? pair.set({ chords: label }) : pair;
  });
}

function fixChordAccidentals(song: ChordSheetJS.Song): ChordSheetJS.Song {
  return song.mapChordLyricsPairs((pair) => {
    if (SECTION_LABEL_RE.test(pair.chords)) return pair;
    const chords = normalizeChord(pair.chords);
    const chord = ChordSheetJS.Chord.parse(chords);
    if (!chord) return pair;
    // Preserve the app's spelling when native formatters apply their key preference.
    for (const note of [chord.root, chord.bass]) {
      if (note) note.contextualSpelling = true;
    }
    return pair.set({ chords, chordObj: chord });
  });
}

function convertToNashville(song: ChordSheetJS.Song, key: string): ChordSheetJS.Song {
  return song.mapChordLyricsPairs((pair) => {
    const chords = pair.chords.trim();
    if (!chords || SECTION_LABEL_RE.test(chords)) return pair;
    try {
      return pair.changeChord((chord) => chord.toNumeric(key));
    } catch { /* skip */ }
    return pair;
  });
}

export function getSongKey(content: string, semitones = 0): string {
  try {
    const parser = new ChordSheetJS.ChordProParser();
    const song = parser.parse(content);
    const transposed = semitones !== 0 ? song.transpose(semitones) : song;
    const key = transposed.key;
    if (key) return normalizeKey(key);
    // Fallback: derive key from first chord
    const root = firstChordRoot(transposed);
    if (root) return normalizeKey(root);
  } catch { /* fall through */ }
  return '';
}

export function songHasKey(content: string, semitones: number): boolean {
  try {
    const song = new ChordSheetJS.ChordProParser().parse(content);
    const transposed = semitones ? song.transpose(semitones) : song;
    return !!transposed.key;
  } catch { return false; }
}

export function clampFontSize(val: number): number {
  return Math.max(-3, Math.min(5, val));
}

export function fontScaleValue(offset: number): string | undefined {
  return offset ? String(1 + offset * 0.12) : undefined;
}

export interface FitLayout {
  fontSize: number;
  twoCol: boolean;
}

/** Largest and smallest font offsets the Fit action will settle on. */
const FIT_MAX_FONT = 3;
const FIT_MIN_FONT = -3;
/** Breathing room kept above and below the sheet, in px. */
const FIT_MARGIN = 24;
/** Must match the min-width of the .two-col rule in chord-sheet.css. */
const TWO_COL_MIN_WIDTH = 640;

/**
 * Layouts the Fit action will try, best first. Largest font wins; at an equal
 * font size two columns win, since they mean less scrolling.
 */
function fitCandidates(isDesktop: boolean): FitLayout[] {
  const candidates: FitLayout[] = [];
  for (let fontSize = FIT_MAX_FONT; fontSize >= FIT_MIN_FONT; fontSize--) {
    if (isDesktop) candidates.push({ fontSize, twoCol: true });
    candidates.push({ fontSize, twoCol: false });
  }
  return candidates;
}

function applyFitLayout(wrap: HTMLElement, { fontSize, twoCol }: FitLayout): void {
  wrap.classList.toggle('two-col', twoCol);
  const scale = fontScaleValue(fontSize);
  if (scale) wrap.style.setProperty('--font-scale', scale);
  else wrap.style.removeProperty('--font-scale');
}

/** Snapshots the wrap's current layout, returning a function that puts it back. */
function captureFitLayout(wrap: HTMLElement): () => void {
  const twoCol = wrap.classList.contains('two-col');
  const scale = wrap.style.getPropertyValue('--font-scale');
  return () => {
    wrap.classList.toggle('two-col', twoCol);
    if (scale) wrap.style.setProperty('--font-scale', scale);
    else wrap.style.removeProperty('--font-scale');
  };
}

/**
 * The smaller of the layout and visual viewports, so mobile browser chrome that
 * is currently hidden cannot be counted as usable height and then reappear when
 * Fit scrolls back to the top. Pinch zoom shrinks the visual viewport without
 * shrinking the screen, so it is ignored while zoomed.
 */
function viewportHeight(): number {
  const visual = window.visualViewport;
  if (!visual || visual.scale > 1) return window.innerHeight;
  return Math.min(window.innerHeight, visual.height);
}

/** Where the sheet starts in the document, independent of the current scroll. */
function documentTop(output: Element): number {
  return output.getBoundingClientRect().top + window.scrollY;
}

/** The playback dock is fixed over the bottom of the screen, so its height is not usable. */
function dockHeight(): number {
  return document.querySelector('.playback-dock')?.getBoundingClientRect().height ?? 0;
}

/**
 * Height the sheet may occupy: the space it actually has where it sits, with the
 * page scrolled to the top. Budgeting a whole screen instead (on the grounds
 * that the header scrolls away) inflated the font until the song fitted at one
 * exact scroll offset and nowhere else. Measured against the viewport and not
 * the wrap, which grows to its own content and so always "fits".
 */
function availableHeight(output: Element): number {
  return viewportHeight() - documentTop(output) - dockHeight() - FIT_MARGIN;
}

function fitsVertically(output: Element): boolean {
  return output.scrollHeight <= availableHeight(output);
}

/**
 * Chord and lyric pairs are laid out as inline-flex columns that do not shrink,
 * so a bigger font or a narrower column can push a line off the side. The wrap
 * scrolls horizontally to hide that, which reads as "it does not fit".
 */
function fitsHorizontally(wrap: Element): boolean {
  return wrap.scrollWidth <= wrap.clientWidth;
}

/**
 * A chord line that wraps drops its tail onto a second visual line, away from
 * the chords above it, so the sheet stops lining up. Two narrow columns cause
 * this long before anything overflows, which is why a layout can measure as
 * fitting and still read as wrong.
 */
function wrapsChordLines(output: Element): boolean {
  for (const row of output.querySelectorAll('.row')) {
    if (row.querySelector('.section-label, h3.label')) continue;
    const pairs = [...row.children];
    if (!pairs.length) continue;
    const tallestPair = Math.max(...pairs.map((pair) => pair.getBoundingClientRect().height));
    if (tallestPair > 0 && row.getBoundingClientRect().height > tallestPair * 1.5) return true;
  }
  return false;
}

export function autoFit(): FitLayout {
  if (typeof window === 'undefined') return { fontSize: 0, twoCol: false };

  const wrap = document.querySelector('.chord-sheet-wrap') as HTMLElement | null;
  const output = wrap?.querySelector('#chord-output') as HTMLElement | null;
  if (!wrap || !output) return { fontSize: 0, twoCol: false };

  const restore = captureFitLayout(wrap);
  const startingTwoCol = wrap.classList.contains('two-col');
  const isDesktop = window.innerWidth >= TWO_COL_MIN_WIDTH;

  const candidates = fitCandidates(isDesktop);
  const fitsOnScreen = (candidate: FitLayout) => {
    applyFitLayout(wrap, candidate);
    return fitsVertically(output) && fitsHorizontally(wrap);
  };

  // Prefer a layout that keeps every chord line intact. Only if no such layout
  // exists is a wrapped one better than nothing.
  const fitted = candidates.find((c) => fitsOnScreen(c) && !wrapsChordLines(output))
    ?? candidates.find(fitsOnScreen);

  restore();
  // Nothing fits at any size. Stay readable at the normal font and leave the
  // column count alone: a layout Fit cannot justify is worse than no change.
  return fitted ?? { fontSize: 0, twoCol: startingTwoCol };
}

export function resolveEffectivePreferences(
  entry: SetlistEntry | null | undefined,
  global: SetlistPreferences
): SetlistPreferences {
  if (!entry) return global;
  return {
    nashville: entry._num != null ? !!entry._num : global.nashville,
    twoCol: entry._twoCol ?? global.twoCol,
    fontSize: entry._font ?? global.fontSize,
    hideYt: entry._hideYt != null ? entry._hideYt : global.hideYt,
  };
}
