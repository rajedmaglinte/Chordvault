import { jsPDF, type jsPDFOptions } from 'jspdf';
import fontUrl from '../assets/NotoSansTC.ttf?url';
import boldFontUrl from '../assets/NotoSansTC-Semibold.ttf?url';
import { EMBEDDED_FONT } from './constants';

// What the jsPDF built-in Latin face can draw: whitespace, ASCII, Latin-1,
// common punctuation, euro. \s matters — song content is full of newlines.
const BUILTIN = /[\s\u0020-\u007E\u00A0-\u00FF\u2010-\u2027\u20AC]/;

// What Noto Sans TC adds: CJK punctuation, kana, strokes, enclosed forms,
// ideographs, compatibility and fullwidth. Hangul is NOT covered — keep this
// in step with the font file or unsupportedChars starts lying.
const EMBEDDED =
  /[\u3000-\u303F\u3040-\u30FF\u31C0-\u31EF\u3200-\u32FF\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF\uFE30-\uFE4F\uFF00-\uFFEF]/;

export function needsEmbeddedFont(text: string): boolean {
  return [...text].some((ch) => !BUILTIN.test(ch));
}

export function unsupportedChars(text: string): string[] {
  return [...new Set([...text].filter((ch) => !BUILTIN.test(ch) && !EMBEDDED.test(ch)))];
}

export interface PdfFontData {
  normal: string;
  bold: string;
}

let cached: Promise<PdfFontData> | null = null;

async function fetchFont(url: string): Promise<string> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`font fetch failed: ${res.status}`);
  const bytes = new Uint8Array(await res.arrayBuffer());
  let bin = '';
  // Chunking avoids the argument limit for the full CJK font.
  for (let i = 0; i < bytes.length; i += 8192) {
    bin += String.fromCharCode(...bytes.subarray(i, i + 8192));
  }
  return btoa(bin);
}

export async function loadPdfFont(text: string): Promise<PdfFontData | null> {
  if (!needsEmbeddedFont(text)) return null;
  // don't cache a rejection — one flaky fetch would break exports until reload
  cached ??= Promise.all([fetchFont(fontUrl), fetchFont(boldFontUrl)]).then(([normal, bold]) => ({ normal, bold })).catch((e) => {
    cached = null;
    throw e;
  });
  return cached;
}

export function makePdfConstructor(fontData: PdfFontData | null) {
  if (!fontData) return jsPDF;
  // re-bound: TS does not carry the null-narrowing into the class body
  const data = fontData;
  return class extends jsPDF {
    // jsPDFOptions, imported directly. ConstructorParameters<typeof jsPDF>[0]
    // looks right but resolves to the orientation overload, not the options one.
    constructor(options?: jsPDFOptions) {
      super(options);
      this.addFileToVFS('notosanstc.ttf', data.normal);
      this.addFileToVFS('notosanstc-semibold.ttf', data.bold);
      this.addFont('notosanstc.ttf', EMBEDDED_FONT, 'normal');
      this.addFont('notosanstc-semibold.ttf', EMBEDDED_FONT, 'bold');
    }
  };
}
