export interface SetlistEntry {
  entry_id: number | string;
  song_id: number;
  title: string;
  artist: string;
  content: string;
  content_override: string | null;
  target_key: string | null;
  nashville: number;
  bpm: number | null;
  /** Metronome for this song in this setlist; null = the song's tempo / 4 beats per bar. */
  metronome_bpm?: number | null;
  metronome_beats?: number | null;
  youtube_url: string | null;
  language: string;
  is_private_placeholder?: boolean;
  is_deactivated?: boolean;
  not_downloaded?: boolean;
  visibility?: string;
  // Per-song overrides (runtime only)
  _num?: number | null;
  _twoCol?: boolean | null;
  _font?: number | null;
  _hideYt?: boolean | null;
}

export interface Setlist {
  id: number | string;
  name: string;
  visibility: string;
  event_date: string | null;
  user_id?: number;
  song_count?: number;
  username?: string;
  entries: SetlistEntry[];
  created_at?: string;
  updated_at?: string;
  isLocal?: boolean;
  search?: string[];
}

export interface SetlistListItem {
  id: number | string;
  name: string;
  visibility: string;
  event_date: string | null;
  song_count: number;
  username?: string;
  created_at?: string;
  updated_at?: string;
}

export interface LocalSetlistEntry {
  song_id: number;
  title: string;
  artist: string;
  target_key?: string | null;  // absent on entries written before 1.23.0
  transpose?: number;          // legacy, read-only
  nashville: number;
  metronome_bpm?: number | null;
  metronome_beats?: number | null;
}

export interface LocalSetlist {
  id: string;
  name: string;
  entries: LocalSetlistEntry[];
}

export interface SetlistPreferences {
  nashville: boolean;
  twoCol: boolean;
  fontSize: number;
  hideYt: boolean;
}
