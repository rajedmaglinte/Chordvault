import { useOffline, useOfflineActivity } from '../context/OfflineContext';
import { useDisclosure } from '@mantine/hooks';
import { Badge, Tabs, Switch, Button, TextInput, SegmentedControl, SimpleGrid, Stack, Group, Text, Box, Input, NumberInput } from '@mantine/core';
import { IconCamera, IconLock } from '@tabler/icons-react';
import { useState, useEffect } from 'react';
import { useApi } from '../hooks/useApi';
import { useAuth } from '../context/AuthContext';
import { isSuperAdmin } from '../lib/constants';
import { useI18n } from '../context/I18nContext';
import { showStatusNotification as toast } from '../lib/notifications';
import { confirmAction, notifyError } from '../lib/errors';
import { useSongEditor } from '../hooks/useSongEditor';
import { TagPicker } from '../components/TagPicker';
import { LanguagePicker } from '../components/LanguagePicker';
import { OcrModal } from '../components/OcrModal';
import { CodeMirrorEditor } from '../components/CodeMirrorEditor';
import { EditorPreview } from '../components/EditorPreview';
import { MoveChordsView } from '../components/MoveChordsView';
import type { EditorView } from '@codemirror/view';
import { extractDirective, updateDirective } from '../lib/chords';
import { createSongVersion, requirePreparedSong } from '../lib/songSubmit';
import type { Song } from '../types';
import { EditorActionBar } from '../components/EditorActionBar';
import type { Destination } from '../lib/songEditRoute';
import { VISIBILITY, MIN_BPM, MAX_BPM, normalizeVisibility, type Visibility } from '../lib/constants';
import { getGeminiKeySaved, getLanguages } from '../lib/settingsApi';
import type { Navigate } from '../lib/routes';

interface SongEditViewProps {
  songId?: number;
  returnTo?: Destination;
  navigate: Navigate;
}

export function SongEditView({ songId, returnTo, navigate }: SongEditViewProps) {
  const apiCall = useApi();
  const { readOnly } = useOffline();
  const { user } = useAuth();
  const { t } = useI18n();
  const [song, setSong] = useState<Song | null>(null);
  const [visibility, setVisibility] = useState<Visibility>(VISIBILITY.PUBLIC);
  const [saved, setSaved] = useState<{ content: string; visibility: Visibility }>({ content: '', visibility: VISIBILITY.PUBLIC });
  const [preferredLanguages, setPreferredLanguages] = useState<string[]>([]);
  const [ocrOpen, ocr] = useDisclosure(false);
  const [hasGeminiKey, setHasGeminiKey] = useState(false);
  const [editorTab, setEditorTab] = useState<'edit' | 'preview'>('edit');
  const [forceRender, setForceRender] = useState(0);
  const [editorView, setEditorView] = useState<EditorView | null>(null);
  const [previewMode, setPreviewMode] = useState<'preview' | 'move'>('preview');

  const editor = useSongEditor();
  const { state, handleContentChange, handleFieldChange, handleTagsChange, handleLanguageChange, setInitialContent } = editor;

  useEffect(() => {
    if (songId) {
      apiCall<Song>('GET', `/api/songs/${songId}`)
        .then((s) => {
          setSong(s);
          setVisibility(normalizeVisibility(s.visibility));

          // CodeMirror joins lines with \n, so CRLF content would read as an unsaved edit.
          let c = s.content.replace(/\r\n?/g, '\n');
          // Inject missing directives from DB columns into content for old songs
          if (s.title && !extractDirective(c, 'title')) c = updateDirective(c, 'title', s.title);
          if (s.artist && !extractDirective(c, 'artist')) c = updateDirective(c, 'artist', s.artist);
          if (s.bpm && !extractDirective(c, 'tempo')) c = updateDirective(c, 'tempo', String(s.bpm));
          if (s.youtube_url && !extractDirective(c, 'x_youtube')) c = updateDirective(c, 'x_youtube', s.youtube_url);
          if (s.tags && !extractDirective(c, 'x_tags')) c = updateDirective(c, 'x_tags', s.tags);
          if (s.language && !extractDirective(c, 'x_language')) c = updateDirective(c, 'x_language', s.language);

          setInitialContent(c);
          setSaved({ content: c, visibility: normalizeVisibility(s.visibility) });
        })
        .catch((e) => { notifyError(e); navigate('my-songs', {}, { leave: true }); });
    }
  }, [songId, apiCall, navigate, setInitialContent]);

  useEffect(() => {
    if (user) {
      getGeminiKeySaved(apiCall).then(setHasGeminiKey).catch(() => {});
      getLanguages(apiCall).then(setPreferredLanguages).catch(() => {});
    }
  }, [apiCall, user]);

  // Leaving the editor replaces its history entry, so Back does not reopen it.
  const leave = (view: string, params: Record<string, string> = {}) => {
    const dest = returnTo ?? { view, params };
    navigate(dest.view, dest.params, { leave: true });
  };

  const save = async () => {
    try {
      const prepared = requirePreparedSong(state.content);
      const body = { content: prepared.content, format_detected: prepared.format, visibility };
      if (song) {
        await apiCall('PUT', `/api/songs/${song.id}`, body);
        toast(t('songEdit.saved'), 'success');
        leave('song-view', { id: String(song.id) });
      } else {
        const result = await apiCall<{ id: number }>('POST', '/api/songs', body);
        toast(t('songEdit.created'), 'success');
        navigate('song-view', { id: String(result.id) }, { leave: true });
      }
    } catch (e) { notifyError(e); }
  };

  // Only the super admin deletes for good; for everyone else the server deactivates the song.
  const superAdmin = isSuperAdmin(user?.role);
  const deleteSong = () => {
    if (!song) return;
    confirmAction(superAdmin ? t('songEdit.confirmDelete') : t('songEdit.confirmDeactivate'), async () => {
      const res = await apiCall<{ result?: string }>('DELETE', `/api/songs/${song.id}`);
      toast(res.result === 'deleted' ? t('songEdit.deleted') : t('songEdit.deactivated'));
      leave('my-songs');
    });
  };

  const cancel = () => {
    if (song) leave('song-view', { id: String(song.id) });
    else leave('my-songs');
  };

  const isOwner = !song || (user && song && user.id === song.user_id);

  const saveAsVersion = async () => {
    const targetId = songId || (song?.id);
    if (!targetId) return;
    try {
      const result = await createSongVersion(apiCall, targetId, state.content);
      toast(t('setlist.versionCreated'), 'success');
      leave('song-view', { id: String(result.id) });
    } catch (e) { notifyError(e); }
  };

  const dirty = state.content !== saved.content || visibility !== saved.visibility;
  useOfflineActivity(dirty);
  const title = songId ? (isOwner ? t('songEdit.editSong') : t('songEdit.createVersion')) : t('songEdit.newSong');

  return (
    <>
      <EditorActionBar
        title={title}
        dirty={dirty}
        onLeave={cancel}
        saveLabel={isOwner ? t('songEdit.save') : t('songEdit.saveAsMyVersion')}
        onSave={isOwner ? save : saveAsVersion}
        onSaveAsVersion={isOwner && songId ? saveAsVersion : undefined}
        onDelete={song && isOwner ? deleteSong : undefined}
        deleteLabel={superAdmin ? t('songEdit.deleteSong') : t('songEdit.deactivateSong')}
      />
      <Stack gap="sm">
        <SimpleGrid cols={{ base: 1, xs: 2 }} spacing="sm">
          <TextInput label={<>{t('songEdit.titleLabel')}</>} type="text" value={state.title} onChange={(e) => handleFieldChange('title', e.target.value, editor.setTitle)} placeholder={t('songEdit.titlePlaceholder')} />
          <TextInput label={<>{t('songEdit.artistLabel')}</>} type="text" value={state.artist} onChange={(e) => handleFieldChange('artist', e.target.value, editor.setArtist)} placeholder={t('songEdit.artistPlaceholder')} />
          <LanguagePicker value={state.language} onChange={handleLanguageChange} preferredLanguages={preferredLanguages} />
          <NumberInput label={<>BPM</>} value={state.bpm} onChange={(value) => handleFieldChange('tempo', String(value), editor.setBpm)} placeholder="e.g. 120" min={MIN_BPM} max={MAX_BPM} clampBehavior="none" allowDecimal={false} allowNegative={false} />
        </SimpleGrid>
        <TextInput label={<>YouTube URL</>} type="url" value={state.youtubeUrl} onChange={(e) => handleFieldChange('x_youtube', e.target.value, editor.setYoutubeUrl)} placeholder="https://youtube.com/watch?v=..." />
        <Input.Wrapper label={t('songs.tags')} labelElement="div">
          <TagPicker label={t('songs.tags')} selected={state.tags} onChange={handleTagsChange} />
        </Input.Wrapper>
        <Switch label={<>Public {visibility === VISIBILITY.PRIVATE && <Text span size="xs" c="dimmed"><IconLock size={12} aria-hidden /> {t('songEdit.privateOnly')}</Text>}</>}
                disabled={!isOwner}
                checked={visibility === VISIBILITY.PUBLIC}
                onChange={(e) => setVisibility(e.target.checked ? VISIBILITY.PUBLIC : VISIBILITY.PRIVATE)}
               />
        <Box>
          <Group align="flex-start" justify="space-between" gap="xs" mb="xs">
            <Text size="xs" c="dimmed" flex="1 1 220px" className="chordpro-hint" dangerouslySetInnerHTML={{ __html: t('songEdit.chordproHint') + ' You can also paste chords-over-lyrics or Ultimate Guitar format. It will be auto-converted.' }} />
            {state.formatBadge && <Badge size="md" h="auto" py={4} color={state.formatBadge.ok ? 'green' : 'orange'} styles={{ root: { flexShrink: state.formatBadge.ok ? 0 : 1 }, label: { whiteSpace: 'normal' } }}>{state.formatBadge.text}</Badge>}
          </Group>
          {user && (
            <Box mb="xs">
              <Button variant="default" size="xs" disabled={readOnly} leftSection={<IconCamera size={14} aria-hidden />} onClick={ocr.open}>Import from image or PDF</Button>
            </Box>
          )}
          <Tabs value={editorTab} onChange={(value) => { if (value === 'preview') { setEditorTab('preview'); setForceRender(n => n + 1); } else setEditorTab('edit'); }} keepMounted keepMountedMode="display-none">
            <Tabs.List grow hiddenFrom="sm"><Tabs.Tab value="edit">{t('songView.edit')}</Tabs.Tab><Tabs.Tab value="preview">Preview</Tabs.Tab></Tabs.List>
            <div className="editor-split">
              <Tabs.Panel value="edit" className="cm-editor-wrap">
                <CodeMirrorEditor
                  value={state.content}
                  onChange={handleContentChange}
                  onViewReady={setEditorView}
                  placeholder={'Paste any format:\n\nChordPro:  [G]Let it [D]be\n\nOr chords over lyrics:\n  G        D\n  Let it be'}
                />
              </Tabs.Panel>
              <Tabs.Panel value="preview" className="editor-preview-wrap">
                <SegmentedControl size="xs" mx={12} mt={12} value={previewMode} onChange={(v) => setPreviewMode(v as 'preview' | 'move')}
                  data={[{ value: 'preview', label: t('moveChords.preview') }, { value: 'move', label: t('moveChords.mode') }]} />
                {previewMode === 'move' && editorView
                  ? <MoveChordsView view={editorView} content={state.content} />
                  : <EditorPreview content={state.content} forceRender={forceRender} />}
              </Tabs.Panel>
            </div>
          </Tabs>
        </Box>
      </Stack>
      <OcrModal
        opened={ocrOpen}
        hasGeminiKey={hasGeminiKey}
        onResult={(text, lang) => {
          let c = text;
          if (lang && !extractDirective(c, 'x_language')) c = updateDirective(c, 'x_language', lang);
          setInitialContent(c);
        }}
        onClose={ocr.close}
      />
    </>
  );
}
